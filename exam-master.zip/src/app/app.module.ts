import { NgModule } from '@angular/core';
import { ToastrModule } from 'ngx-toastr';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { CoreModule } from '@core/core.module';
import { ConfirmationService } from 'primeng/api';
import { LayoutsModule } from '@core/layouts.module';
import { AppRoutingModule } from './app-routing.module';
import { CustomToastComponent } from '@shared/components';
import { BrowserModule } from '@angular/platform-browser';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
	bootstrap: [AppComponent],
	providers: [ConfirmationService],
	declarations: [AppComponent, CustomToastComponent],
	imports: [
		CoreModule,
		CommonModule,
		BrowserModule,
		LayoutsModule,
		AppRoutingModule,
		ConfirmDialogModule,
		BrowserAnimationsModule,
		ToastrModule.forRoot({
			maxOpened: 0,
			timeOut: 5000,
			closeButton: true,
			tapToDismiss: false,
			extendedTimeOut: 2000,
			preventDuplicates: true,
			toastClass: 'custom-toast-outer',
			positionClass: 'toast-bottom-center',
			toastComponent: CustomToastComponent
		})
	]
})
export class AppModule {}
