import CryptoJS from 'crypto-js';
import { appSettings } from '@app/configs';

/**
 * *Encryptes data using crypto js
 *
 * @param data
 * @returns string
 * @date 04 July 2023
 * @developer Pritam Kundu
 */
export function encryption(data: string): string {
	const SECRET = appSettings.cryptoSecret;

	const b64 = CryptoJS.AES.encrypt(data, SECRET).toString();
	const e64 = CryptoJS.enc.Base64.parse(b64);
	const eHex = e64.toString(CryptoJS.enc.Hex);

	return eHex;
}

/**
 * *Decryptes encrypted string using crypto js
 *
 * @param cipherText
 * @returns number
 * @date 04 July 2023
 * @developer Pritam Kundu
 */
export function decryption(cipherText: string): string {
	const SECRET = appSettings.cryptoSecret;

	const reb64 = CryptoJS.enc.Hex.parse(cipherText);
	const bytes = reb64.toString(CryptoJS.enc.Base64);
	const decrypt = CryptoJS.AES.decrypt(bytes, SECRET);
	const plain = decrypt.toString(CryptoJS.enc.Utf8);

	return plain;
}
