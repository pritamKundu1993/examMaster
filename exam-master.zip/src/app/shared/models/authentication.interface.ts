export interface IStudentAuth {
	id: number;
	name: string;
	email: string;
	studentId: string;
}

export interface IAdminAuth {
	id: number;
	name: string;
	email: string;
}
