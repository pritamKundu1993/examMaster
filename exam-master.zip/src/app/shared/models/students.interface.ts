export interface IStudent {
	id: number;
	name: string;
	email: string;
	mobile: string;
	studentId: string;
	collapsed: boolean;
	exams: IStudentExam[];
}

export interface IStudentExam {
	examTime: Date;
	examDate: Date;
	course: string;
}
