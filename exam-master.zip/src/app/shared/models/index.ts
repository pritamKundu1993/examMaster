export * from './students.interface';
export * from './authentication.interface';
export * from './admin.interface';
