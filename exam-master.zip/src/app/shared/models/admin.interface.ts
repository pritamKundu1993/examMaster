export interface IAdmin {
	id: number;
	name: string;
	email: string;
	mobile: string;
	password: string;
}
