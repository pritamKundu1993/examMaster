import { Component } from '@angular/core';
import { Toast, ToastPackage, ToastrService } from 'ngx-toastr';

@Component({
	selector: 'custom-toast',
	templateUrl: './custom-toast.component.html',
	styleUrls: ['./custom-toast.component.css']
})
export class CustomToastComponent extends Toast {
	constructor(
		public override toastPackage: ToastPackage,
		protected override toastrService: ToastrService
	) {
		super(toastrService, toastPackage);
	}
}
