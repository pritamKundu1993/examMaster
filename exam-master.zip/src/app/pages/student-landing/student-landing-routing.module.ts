import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Components import
import { StudentLandingComponent } from './components';

const landingRoutes: Routes = [
	{
		path: '',
		title: 'Student Homepage',
		component: StudentLandingComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(landingRoutes)],
	exports: [RouterModule]
})
export class StudentLandingRoutingModule {}
