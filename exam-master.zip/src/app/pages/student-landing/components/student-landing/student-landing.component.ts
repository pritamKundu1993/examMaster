import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'student-landing',
	templateUrl: './student-landing.component.html',
	styleUrls: ['./student-landing.component.css']
})
export class StudentLandingComponent implements OnInit {
	constructor() {}

	ngOnInit(): void {}
}
