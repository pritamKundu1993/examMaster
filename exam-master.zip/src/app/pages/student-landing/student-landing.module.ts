import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentLandingRoutingModule } from './student-landing-routing.module';

//Components import
import { StudentLandingComponent } from './components';

@NgModule({
	declarations: [StudentLandingComponent],
	imports: [CommonModule, StudentLandingRoutingModule]
})
export class StudentLandingModule {}
