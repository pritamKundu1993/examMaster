import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Componenets import
import {
	StudentLoginComponent,
	StudentRegistrationComponent
} from './components';

//Guards import
import { SecureOuterPagesGuard } from '@core/guards';

const studentAuthRoutes: Routes = [
	{
		path: 'student-login',
		title: 'Student Login',
		component: StudentLoginComponent,
		canActivate: [SecureOuterPagesGuard]
	},
	{
		path: 'student-registration',
		title: 'Student Registration',
		canActivate: [SecureOuterPagesGuard],
		component: StudentRegistrationComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(studentAuthRoutes)],
	exports: [RouterModule]
})
export class StudentAuthRoutingModule {}
