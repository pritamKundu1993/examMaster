import { NgModule } from '@angular/core';
import { NgxMaskModule } from 'ngx-mask';
import { CommonModule } from '@angular/common';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentAuthRoutingModule } from './student-auth-routing.module';

//Componenets import
import {
	StudentLoginComponent,
	StudentRegistrationComponent
} from './components';

@NgModule({
	declarations: [StudentLoginComponent, StudentRegistrationComponent],
	imports: [
		FormsModule,
		CommonModule,
		CalendarModule,
		ReactiveFormsModule,
		NgxMaskModule.forRoot(),
		StudentAuthRoutingModule
	]
})
export class StudentAuthModule {}
