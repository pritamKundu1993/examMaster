export * from './student-login/student-login.component';
export * from './student-registration/student-registration.component';
