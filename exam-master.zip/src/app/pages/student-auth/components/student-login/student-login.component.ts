import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { StudentsService } from '@core/services';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthenticationService } from '@core/authentication';
import {
	FormGroup,
	Validators,
	FormControl,
	FormBuilder,
	AbstractControl
} from '@angular/forms';

@Component({
	selector: 'student-login',
	templateUrl: './student-login.component.html',
	styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit, OnDestroy {
	constructor(
		private _router: Router,
		private _toastr: ToastrService,
		private _formBuilder: FormBuilder,
		private _studentsService: StudentsService,
		private _authService: AuthenticationService
	) {}

	public maskPrefix: string = '';
	public submitted: boolean = false;
	public isDisabled: boolean = false;
	public studentProfileForm!: FormGroup;
	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.initStudentProfileForm();
	}

	private initStudentProfileForm(): void {
		this.studentProfileForm = this._formBuilder.group({
			studentId: new FormControl('', {
				nonNullable: true,
				validators: [
					Validators.required,
					Validators.pattern('^[0-9-]+$')
				]
			}),
			mobile: new FormControl('', {
				nonNullable: true,
				validators: [
					Validators.required,
					Validators.pattern('^[0-9-]+$')
				]
			})
		});
	}

	public get formControl(): { [key: string]: AbstractControl } {
		return this.studentProfileForm.controls;
	}

	public hasFormControlError(field: string): boolean {
		const control = this.studentProfileForm.get(field) as FormControl;

		if (
			(this.submitted && control.errors) ||
			(control.invalid && control.dirty)
		) {
			return true;
		}
		return false;
	}

	public loginOnSubmit(): boolean | void {
		if (!this.isDisabled) {
			this.submitted = true;

			// stop here if form is invalid
			if (this.studentProfileForm.invalid) {
				return true;
			}

			const formValue = this.studentProfileForm.value;

			this.subscriptions.push(
				this._studentsService
					.fetchStudent(formValue.studentId)
					.subscribe({
						next: (student) => {
							if (!!student) {
								this._authService.setStudentAccessToken(
									student
								);

								this._router.navigate(['student-profile']);

								this._toastr.success(
									'You are successfully authenticated and logged in.'
								);
							} else {
								this._toastr.error(
									'There is no student associated with this student id.'
								);
							}
						},
						error: (apiError) => {
							console.log(apiError);
							this._toastr.error(
								'Oops! Something went wrong. Please try again later.'
							);
						}
					})
			);
		}
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
