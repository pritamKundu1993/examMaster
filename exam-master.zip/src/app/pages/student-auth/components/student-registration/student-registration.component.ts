import { ToastrService } from 'ngx-toastr';
import { Subscription, mergeMap } from 'rxjs';
import { StudentsService } from '@core/services';
import { IStudent, IStudentExam } from '@shared/models';
import { Component, OnInit, OnDestroy } from '@angular/core';
import {
	FormGroup,
	Validators,
	FormControl,
	FormBuilder,
	AbstractControl
} from '@angular/forms';

@Component({
	selector: 'student-registration',
	templateUrl: './student-registration.component.html',
	styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements OnInit, OnDestroy {
	constructor(
		private _toastr: ToastrService,
		private _formBuilder: FormBuilder,
		private _studentsService: StudentsService
	) {}

	public submitted: boolean = false;
	public isDisabled: boolean = false;
	public studentRegisterForm!: FormGroup;
	public isExamDateVisible: boolean = false;
	public isExamTimeVisible: boolean = false;
	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.initStudentRegisterForm();
	}

	private initStudentRegisterForm(): void {
		this.studentRegisterForm = this._formBuilder.group({
			studentId: new FormControl('', {
				nonNullable: true,
				validators: [
					Validators.required,
					Validators.pattern('^[0-9-]+$')
				]
			}),
			name: new FormControl('', {
				nonNullable: true,
				validators: [
					Validators.required,
					Validators.pattern('^[A-Za-z ]+$')
				]
			}),
			course: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			}),
			mobile: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			}),
			email: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required, Validators.email]
			}),
			examDate: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			}),
			examTime: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			})
		});
	}

	public get formControl(): { [key: string]: AbstractControl } {
		return this.studentRegisterForm.controls;
	}

	public hasFormControlError(field: string): boolean {
		const control = this.studentRegisterForm.get(field) as FormControl;

		if (
			control &&
			((this.submitted && control.errors) ||
				(control.invalid && control.dirty))
		) {
			return true;
		}

		return false;
	}

	public registerOnSubmit(): boolean | void {
		if (!this.isDisabled) {
			this.submitted = true;

			if (this.studentRegisterForm.invalid) {
				return true;
			}

			const formValue = this.studentRegisterForm.value;

			const payload: Partial<IStudent> = {
				name: formValue.name,
				email: formValue.email,
				mobile: formValue.mobile,
				studentId: formValue.studentId
			};

			const examPayload: IStudentExam = {
				course: formValue.course,
				examTime: formValue.examTime,
				examDate: formValue.examDate
			};

			this.subscriptions.push(
				this._studentsService
					.fetchStudent(formValue.studentId)
					.pipe(
						mergeMap((student) => {
							if (!!student) {
								student.exams.push(examPayload);
								return this._studentsService.updateStudent(
									student
								);
							} else {
								payload.exams = [examPayload];
								return this._studentsService.addStudent(
									payload as IStudent
								);
							}
						})
					)
					.subscribe({
						next: () => {
							this.submitted = false;
							this.studentRegisterForm.reset();
							this.studentRegisterForm.updateValueAndValidity();
							this.studentRegisterForm.markAsPristine();

							this._toastr.success(
								"You've successfully enrolled for the exam."
							);
						},
						error: (apiError) => {
							console.log(apiError);
							this._toastr.error(
								'Oops! Something went wrong. Please try again later.'
							);
						}
					})
			);
		}
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
