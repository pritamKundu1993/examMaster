export * from './student-exam-registration/student-exam-registration.component';
