import { NgModule } from '@angular/core';
import { NgxMaskModule } from 'ngx-mask';
import { CommonModule } from '@angular/common';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentExamRegistrationRoutingModule } from './student-exam-registration-routing.module';

//Componenets import
import { StudentExamRegistrationComponent } from './components';

@NgModule({
	declarations: [StudentExamRegistrationComponent],
	imports: [
		FormsModule,
		CommonModule,
		CalendarModule,
		ReactiveFormsModule,
		NgxMaskModule.forRoot(),
		StudentExamRegistrationRoutingModule
	]
})
export class StudentExamRegistrationModule {}
