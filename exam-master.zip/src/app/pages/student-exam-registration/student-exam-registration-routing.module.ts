import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Componenets import
import { StudentExamRegistrationComponent } from './components';

const examRegistrationRoutes: Routes = [
	{
		path: '',
		title: 'Student Exam Registration',
		component: StudentExamRegistrationComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(examRegistrationRoutes)],
	exports: [RouterModule]
})
export class StudentExamRegistrationRoutingModule {}
