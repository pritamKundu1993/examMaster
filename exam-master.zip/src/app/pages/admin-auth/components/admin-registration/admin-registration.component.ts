import { IAdmin } from '@shared/models';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from '@core/services';
import { Subscription, mergeMap, of } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import {
	FormGroup,
	Validators,
	FormControl,
	FormBuilder,
	AbstractControl
} from '@angular/forms';

@Component({
	selector: 'admin-registration',
	templateUrl: './admin-registration.component.html',
	styleUrls: ['./admin-registration.component.css']
})
export class AdminRegistrationComponent implements OnInit, OnDestroy {
	constructor(
		private _toastr: ToastrService,
		private _formBuilder: FormBuilder,
		private _adminService: AdminService
	) {}

	public submitted: boolean = false;
	public isDisabled: boolean = false;
	public adminRegisterForm!: FormGroup;
	public isExamDateVisible: boolean = false;
	public isExamTimeVisible: boolean = false;
	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.initAdminRegisterForm();
	}

	private initAdminRegisterForm(): void {
		this.adminRegisterForm = this._formBuilder.group({
			name: new FormControl('', {
				nonNullable: true,
				validators: [
					Validators.required,
					Validators.pattern('^[A-Za-z ]+$')
				]
			}),
			mobile: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			}),
			email: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required, Validators.email]
			}),
			password: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			})
		});
	}

	public get formControl(): { [key: string]: AbstractControl } {
		return this.adminRegisterForm.controls;
	}

	public hasFormControlError(field: string): boolean {
		const control = this.adminRegisterForm.get(field) as FormControl;

		if (
			control &&
			((this.submitted && control.errors) ||
				(control.invalid && control.dirty))
		) {
			return true;
		}

		return false;
	}

	public registerOnSubmit(): boolean | void {
		if (!this.isDisabled) {
			this.submitted = true;

			if (this.adminRegisterForm.invalid) {
				return true;
			}

			const formValue = this.adminRegisterForm.value;

			const payload: Partial<IAdmin> = {
				name: formValue.name,
				email: formValue.email,
				mobile: formValue.mobile,
				password: formValue.password
			};
			this.subscriptions.push(
				this._adminService
					.fetchAdmin(formValue.email)
					.pipe(
						mergeMap((admin) => {
							if (!!admin) {
								return of(null);
							} else {
								return this._adminService.addAdmin(
									payload as IAdmin
								);
							}
						})
					)
					.subscribe({
						next: (ApiResult) => {
							if (!ApiResult) {
								this._toastr.error(
									'The provided e-mail is already in use by an existing user.'
								);
							} else {
								this.submitted = false;
								this.adminRegisterForm.reset();
								this.adminRegisterForm.updateValueAndValidity();
								this.adminRegisterForm.markAsPristine();

								this._toastr.success(
									'Your account has been successfully created.'
								);
							}
						},
						error: (apiError) => {
							console.log(apiError);
							this._toastr.error(
								'Oops! Something went wrong. Please try again later.'
							);
						}
					})
			);
		}
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
