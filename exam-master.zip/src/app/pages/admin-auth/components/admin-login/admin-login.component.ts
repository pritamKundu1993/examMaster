import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from '@core/services';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthenticationService } from '@core/authentication';
import {
	FormGroup,
	Validators,
	FormControl,
	FormBuilder,
	AbstractControl
} from '@angular/forms';

@Component({
	selector: 'admin-login',
	templateUrl: './admin-login.component.html',
	styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit, OnDestroy {
	constructor(
		private _router: Router,
		private _toastr: ToastrService,
		private _formBuilder: FormBuilder,
		private _adminService: AdminService,
		private _authService: AuthenticationService
	) {}

	public maskPrefix: string = '';
	public submitted: boolean = false;
	public isDisabled: boolean = false;
	public adminProfileForm!: FormGroup;
	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.initAdminProfileForm();
	}

	private initAdminProfileForm(): void {
		this.adminProfileForm = this._formBuilder.group({
			email: new FormControl('', {
				nonNullable: true,
				validators: [Validators.email, Validators.required]
			}),
			password: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			})
		});
	}

	public get formControl(): { [key: string]: AbstractControl } {
		return this.adminProfileForm.controls;
	}

	public hasFormControlError(field: string): boolean {
		const control = this.adminProfileForm.get(field) as FormControl;

		if (
			(this.submitted && control.errors) ||
			(control.invalid && control.dirty)
		) {
			return true;
		}
		return false;
	}

	public loginOnSubmit(): boolean | void {
		if (!this.isDisabled) {
			this.submitted = true;

			// stop here if form is invalid
			if (this.adminProfileForm.invalid) {
				return true;
			}

			const formValue = this.adminProfileForm.value;

			this.subscriptions.push(
				this._adminService
					.fetchAdmin(formValue.email, formValue.password)
					.subscribe({
						next: (admin) => {
							if (!!admin) {
								this._authService.setAdminAccessToken(admin);
								this._router.navigate(['/admin/dashboard']);

								this._toastr.success(
									'You are successfully authenticated and logged in.'
								);
							} else {
								this._toastr.error(
									'There is no user associated with this e-mail address.'
								);
							}
						},
						error: (apiError) => {
							console.log(apiError);
							this._toastr.error(
								'Oops! Something went wrong. Please try again later.'
							);
						}
					})
			);
		}
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
