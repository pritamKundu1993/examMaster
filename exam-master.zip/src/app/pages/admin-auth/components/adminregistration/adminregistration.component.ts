import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'adminregistration',
  templateUrl: './adminregistration.component.html',
  styleUrls: ['./adminregistration.component.css']
})
export class AdminregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
