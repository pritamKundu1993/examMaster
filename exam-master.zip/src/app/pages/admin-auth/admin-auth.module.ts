import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxMaskModule } from 'ngx-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminAuthRoutingModule } from './admin-auth-routing.module';

//Components import
import { AdminLoginComponent, AdminRegistrationComponent } from './components';

@NgModule({
	declarations: [AdminLoginComponent, AdminRegistrationComponent],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		NgxMaskModule.forRoot(),
		AdminAuthRoutingModule
	]
})
export class AdminAuthModule {}
