export * from './student-profile/student-profile.component';
