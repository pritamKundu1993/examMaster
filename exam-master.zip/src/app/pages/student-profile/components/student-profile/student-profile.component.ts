import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { StudentsService } from '@core/services';
import { IStudent, IStudentExam } from '@shared/models';
import { AuthenticationService } from '@core/authentication';
import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
	selector: 'student-profile',
	templateUrl: './student-profile.component.html',
	styleUrls: ['./student-profile.component.css']
})
export class StudentProfileComponent implements OnInit, OnDestroy {
	constructor(
		private _toastr: ToastrService,
		private _studentsService: StudentsService,
		private _authService: AuthenticationService
	) {
		this.getStudentDetailsFromStotage();
	}

	private studentId!: string;
	public studentDetails!: IStudent;
	public studentExamDetails!: IStudentExam;
	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.getStudentDetailsById();
	}

	private getStudentDetailsFromStotage(): void {
		const storageData = this._authService.getDecryptedStudentDetails();
		if (!!storageData) this.studentId = storageData.studentId;
	}

	private getStudentDetailsById(): void {
		this.subscriptions.push(
			this._studentsService.fetchStudent(this.studentId).subscribe({
				next: (apiResult) => {
					if (!!apiResult) this.studentDetails = apiResult;
				},
				error: (apiError) => {
					console.log(apiError);
					this._toastr.error(
						'Oops! Something went wrong. Please try again later.'
					);
				}
			})
		);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
