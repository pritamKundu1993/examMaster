import { NgModule } from '@angular/core';
import { NgxMaskModule } from 'ngx-mask';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentProfileRoutingModule } from './student-profile-routing.module';

//Components import
import { StudentProfileComponent } from './components';

@NgModule({
	declarations: [StudentProfileComponent],
	imports: [
		FormsModule,
		CommonModule,
		ReactiveFormsModule,
		NgxMaskModule.forRoot(),
		StudentProfileRoutingModule
	]
})
export class StudentProfileModule {}
