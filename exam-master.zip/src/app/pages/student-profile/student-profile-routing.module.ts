import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Components import
import { StudentProfileComponent } from './components';

//Guards import
import { StudentAuthGuard } from '@core/guards';

const profileRoutes: Routes = [
	{
		path: '',
		title: 'Student Profile',
		canActivate: [StudentAuthGuard],
		component: StudentProfileComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(profileRoutes)],
	exports: [RouterModule]
})
export class StudentProfileRoutingModule {}
