import { Panel } from 'primeng/panel';
import { ToastrService } from 'ngx-toastr';
import { Subscription, forkJoin } from 'rxjs';
import { ConfirmationService } from 'primeng/api';
import { AuthenticationService } from '@core/authentication';
import { AdminService, StudentsService } from '@core/services';
import { IAdmin, IStudent, IStudentExam } from '@shared/models';
import {
	FormGroup,
	Validators,
	FormControl,
	FormBuilder,
	AbstractControl
} from '@angular/forms';
import {
	OnInit,
	Component,
	OnDestroy,
	QueryList,
	ViewChildren
} from '@angular/core';

@Component({
	selector: 'admin-dashboard',
	templateUrl: './admin-dashboard.component.html',
	styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
	constructor(
		private _toastr: ToastrService,
		private _formBuilder: FormBuilder,
		private _adminService: AdminService,
		private _studentsService: StudentsService,
		private _authService: AuthenticationService,
		private _confirmationService: ConfirmationService
	) {
		this.initEditExamForm();
		this.getAdminDetailsFromStotage();
	}

	private adminEmail!: string;
	public adminDetails!: IAdmin;
	public editExamForm!: FormGroup;
	public students: IStudent[] = [];
	public submitted: boolean = false;
	public isDisabled: boolean = false;
	public isExamDateVisible: boolean = false;
	public isExamTimeVisible: boolean = false;
	private subscriptions: Subscription[] = [];
	public isEditExamSidebarOpen: boolean = false;
	@ViewChildren(Panel) panelInstances!: QueryList<Panel>;

	ngOnInit(): void {
		this.getInitialDataOnLoad();
	}

	private initEditExamForm(): void {
		this.editExamForm = this._formBuilder.group({
			studentId: new FormControl('', {
				nonNullable: true
			}),
			name: new FormControl('', {
				nonNullable: true
			}),
			course: new FormControl('', {
				nonNullable: true
			}),
			examDate: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			}),
			examTime: new FormControl('', {
				nonNullable: true,
				validators: [Validators.required]
			})
		});
	}

	public get formControl(): { [key: string]: AbstractControl } {
		return this.editExamForm.controls;
	}

	public hasFormControlError(field: string): boolean {
		const control = this.editExamForm.get(field) as FormControl;

		if (
			control &&
			((this.submitted && control.errors) ||
				(control.invalid && control.dirty))
		) {
			return true;
		}

		return false;
	}

	public onEditStudentExam(
		event: Event,
		student: IStudent,
		exam: IStudentExam
	): void {
		event.preventDefault();

		this.editExamForm.patchValue({
			name: student.name,
			course: exam.course,
			studentId: student.studentId,
			examDate: new Date(exam.examDate),
			examTime: new Date(exam.examTime)
		});

		this.isEditExamSidebarOpen = true;
	}

	public onCloseEditExamSidebar(event?: Event): void {
		if (event) event.preventDefault();

		this.isEditExamSidebarOpen = false;

		setTimeout(() => {
			this.submitted = false;
			this.editExamForm.reset();
			this.editExamForm.updateValueAndValidity();
			this.editExamForm.markAsPristine();
		}, 300);
	}

	public editExamOnSubmit(): boolean | void {
		if (!this.isDisabled) {
			this.submitted = true;

			if (this.editExamForm.invalid) {
				return true;
			}

			const formValue = this.editExamForm.value;

			const student = this.students.find(
				(student) => student.studentId === formValue.studentId
			);

			if (!student) {
				this._toastr.error(
					'There is no student associated with this student id.'
				);

				return true;
			}

			student.exams = student.exams.map((exam) => {
				if (exam.course === formValue.course) {
					return {
						...exam,
						examDate: formValue.examDate,
						examTime: formValue.examTime
					};
				}
				return exam;
			});

			this.subscriptions.push(
				this._studentsService.updateStudent(student).subscribe({
					next: (apiResult) => {
						this.students.forEach((student) => {
							if (student.studentId === student.studentId) {
								student = student;
							}
						});

						this.onCloseEditExamSidebar();
						this._toastr.success(
							"You've successfully updated exam details."
						);
					},
					error: (apiError) => {
						console.log(apiError);
						this._toastr.error(
							'Oops! Something went wrong. Please try again later.'
						);
					}
				})
			);
		}
	}

	private getAdminDetailsFromStotage(): void {
		const storageData = this._authService.getDecryptedAdminDetails();
		if (!!storageData) this.adminEmail = storageData.email;
	}

	private getInitialDataOnLoad(): void {
		const _studentsList$ = this._studentsService.fetchStudents();
		const _adminDetails$ = this._adminService.fetchAdmin(this.adminEmail);

		this.subscriptions.push(
			forkJoin([_studentsList$, _adminDetails$]).subscribe({
				next: (apiResults) => {
					const [students, adminDetails] = apiResults;

					this.students = students.map((student, index) => ({
						...student,
						collapsed: index === 0 ? false : true
					}));

					if (!!adminDetails) this.adminDetails = adminDetails;
				},
				error: (apiError) => {
					console.log(apiError);
					this._toastr.error(
						'Oops! Something went wrong. Please try again later.'
					);
				}
			})
		);
	}

	public onToggleStudentPanel(
		student: IStudent,
		studentPanel: Panel,
		event: { originalEvent: Event; collapsed: boolean }
	): void {
		this.panelInstances.forEach((panel) => {
			if (panel !== studentPanel && !panel.collapsed) {
				panel.toggle(event.originalEvent);

				this.students.forEach((_student) => {
					if (_student.id !== student.id) _student.collapsed = true;
				});
			}
		});
	}

	public onDeleteStudent(event: Event, student: IStudent): void {
		event.stopPropagation();

		if (!this.isDisabled) {
			this._confirmationService.confirm({
				message: `<strong>Delete Student?</strong><p>Are you sure that you want to perform this action?</p>`,
				accept: () => {
					this.subscriptions.push(
						this._studentsService
							.deleteStudent(student.id)
							.subscribe({
								next: (apiResult) => {
									this.students = this.students.filter(
										(_student) => _student.id !== student.id
									);
									this._toastr.success(
										'Student deleted Successfully!'
									);
								},
								error: (apiError) => {
									console.log(apiError);
									this._toastr.error(
										'Oops! Something went wrong. Please try again later.'
									);
								}
							})
					);
				}
			});
		}
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
