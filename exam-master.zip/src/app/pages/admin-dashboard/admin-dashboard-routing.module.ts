import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Guards import
import { AdminAuthGuard } from '@app/core/guards';

//Components import
import { AdminDashboardComponent } from './components';

const routes: Routes = [
	{
		path: '',
		title: 'Admin Dashboard',
		canActivate: [AdminAuthGuard],
		component: AdminDashboardComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AdminDashboardRoutingModule {}
