import { NgxMaskModule } from 'ngx-mask';
import { NgModule } from '@angular/core';
import { PanelModule } from 'primeng/panel';
import { CommonModule } from '@angular/common';
import { SidebarModule } from 'primeng/sidebar';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardRoutingModule } from './admin-dashboard-routing.module';

//Components import
import { AdminDashboardComponent } from './components';

@NgModule({
	declarations: [AdminDashboardComponent],
	imports: [
		FormsModule,
		PanelModule,
		CommonModule,
		SidebarModule,
		CalendarModule,
		ReactiveFormsModule,
		NgxMaskModule.forRoot(),
		AdminDashboardRoutingModule
	]
})
export class AdminDashboardModule {}
