import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//Student layout components import
import {
	StudentAuthLayoutComponent,
	StudentMasterLayoutComponent
} from '@core/layouts/student';

//Admin layout components import
import {
	AdminAuthLayoutComponent,
	AdminMasterLayoutComponent
} from '@core/layouts/admin';

const appRoutes: Routes = [
	{
		path: 'auth',
		component: StudentAuthLayoutComponent,
		loadChildren: () =>
			import('./pages/student-auth/student-auth.module').then(
				(m) => m.StudentAuthModule
			)
	},
	{
		path: '',
		component: StudentMasterLayoutComponent,
		children: [
			{
				path: '',
				redirectTo: 'home',
				pathMatch: 'full'
			},
			{
				path: 'home',
				loadChildren: () =>
					import(
						'./pages/student-landing/student-landing.module'
					).then((m) => m.StudentLandingModule)
			},
			{
				path: 'student-profile',
				loadChildren: () =>
					import(
						'./pages/student-profile/student-profile.module'
					).then((m) => m.StudentProfileModule)
			}
		]
	},
	{
		path: 'admin',
		children: [
			{
				path: 'auth',
				component: AdminAuthLayoutComponent,
				loadChildren: () =>
					import('./pages/admin-auth/admin-auth.module').then(
						(m) => m.AdminAuthModule
					)
			},
			{
				path: '',
				component: AdminMasterLayoutComponent,
				children: [
					{
						path: 'dashboard',
						loadChildren: () =>
							import(
								'./pages/admin-dashboard/admin-dashboard.module'
							).then((m) => m.AdminDashboardModule)
					}
				]
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forRoot(appRoutes)],
	exports: [RouterModule]
})
export class AppRoutingModule {}
