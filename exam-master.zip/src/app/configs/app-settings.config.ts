export const appSettings = {
	appTitle: 'Exam Master',
	appTitleSeperator: ' | ',
	adminCredentialsKey: 'admin-user',
	studentCredentialsKey: 'student-user',
	cryptoSecret: 'zsgj8o4ugor4c47red9kcwd0tikq237efcqumg4b4totipxhab'
};
