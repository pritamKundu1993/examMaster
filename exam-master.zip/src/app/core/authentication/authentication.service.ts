import { Injectable } from '@angular/core';
import { appSettings } from '@app/configs';
import { IAdmin, IAdminAuth, IStudent, IStudentAuth } from '@shared/models';
import { decryption, encryption } from '@shared/utilities';

@Injectable()
export class AuthenticationService {
	constructor() {}

	private storage: Storage = sessionStorage;
	private adminCredentials = appSettings.adminCredentialsKey;
	private studentCredentials = appSettings.studentCredentialsKey;

	public setStudentAccessToken(student: IStudent): void {
		const tokenPayload: IStudentAuth = {
			id: student.id,
			name: student.name,
			email: student.email,
			studentId: student.studentId
		};
		const encrypted = encryption(JSON.stringify(tokenPayload));

		this.storage.setItem(this.studentCredentials, encrypted);
	}

	public getStudentAccessToken(): string | null {
		try {
			const storageData = this.storage.getItem(this.studentCredentials);
			return storageData;
		} catch (error) {
			console.log('Error retreiving student storage data.');
			return null;
		}
	}

	public getDecryptedStudentDetails(): null | IStudentAuth {
		try {
			const storageData = this.storage.getItem(this.studentCredentials);
			const savedCredentials: IStudentAuth = !!storageData
				? JSON.parse(decryption(storageData))
				: null;
			return savedCredentials;
		} catch (error) {
			console.log('Error retreiving student storage data.');
			return null;
		}
	}

	public isStudentAuthenticated(): boolean {
		if (!!this.getStudentAccessToken()) {
			return true;
		}
		return false;
	}

	public clearStudentAccessToken(): void {
		this.storage.removeItem(this.studentCredentials);
	}

	public setAdminAccessToken(admin: IAdmin): void {
		const tokenPayload: IAdminAuth = {
			id: admin.id,
			name: admin.name,
			email: admin.email
		};
		const encrypted = encryption(JSON.stringify(tokenPayload));

		this.storage.setItem(this.adminCredentials, encrypted);
	}

	public getAdminAccessToken(): string | null {
		try {
			const storageData = this.storage.getItem(this.adminCredentials);
			return storageData;
		} catch (error) {
			console.log('Error retreiving admin storage data.');
			return null;
		}
	}

	public getDecryptedAdminDetails(): null | IAdminAuth {
		try {
			const storageData = this.storage.getItem(this.adminCredentials);
			const savedCredentials: IAdminAuth = !!storageData
				? JSON.parse(decryption(storageData))
				: null;
			return savedCredentials;
		} catch (error) {
			console.log('Error retreiving student storage data.');
			return null;
		}
	}

	public isAdminAuthenticated(): boolean {
		if (!!this.getAdminAccessToken()) {
			return true;
		}
		return false;
	}

	public clearAdminAccessToken(): void {
		this.storage.removeItem(this.studentCredentials);
	}
}
