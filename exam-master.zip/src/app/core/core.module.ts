import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TitleStrategy } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

//Strategies import
import { TitleStrategyService } from './strategies';

//Services import
import { AdminService, StudentsService } from './services';

//Authentication service import
import { AuthenticationService } from './authentication';

//Guards import
import {
	AdminAuthGuard,
	StudentAuthGuard,
	SecureOuterPagesGuard
} from './guards';

const PROVIDERS = [
	AdminService,
	AdminAuthGuard,
	StudentsService,
	StudentAuthGuard,
	AuthenticationService,
	SecureOuterPagesGuard,
	{
		provide: TitleStrategy,
		useClass: TitleStrategyService
	}
];

@NgModule({
	declarations: [],
	providers: [...PROVIDERS],
	imports: [CommonModule, HttpClientModule]
})
export class CoreModule {}
