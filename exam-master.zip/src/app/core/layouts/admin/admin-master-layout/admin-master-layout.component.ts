import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-master-layout',
	templateUrl: './admin-master-layout.component.html',
	styleUrls: ['./admin-master-layout.component.css']
})
export class AdminMasterLayoutComponent implements OnInit {
	constructor() {}

	ngOnInit(): void {}
}
