import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '@core/authentication';

@Component({
	selector: 'admin-master-header',
	templateUrl: './admin-master-header.component.html',
	styleUrls: ['./admin-master-header.component.css']
})
export class AdminMasterHeaderComponent implements OnInit {
	constructor(
		private _router: Router,
		private _authService: AuthenticationService
	) {}

	ngOnInit(): void {}

	public onLogoutAdmin(event: MouseEvent): void {
		event.preventDefault();
		this._authService.clearAdminAccessToken();
		this._router.navigate(['/home']);
	}
}
