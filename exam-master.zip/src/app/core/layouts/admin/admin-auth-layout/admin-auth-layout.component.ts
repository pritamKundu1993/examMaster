import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-auth-layout',
	templateUrl: './admin-auth-layout.component.html',
	styleUrls: ['./admin-auth-layout.component.css']
})
export class AdminAuthLayoutComponent implements OnInit {
	constructor() {}

	ngOnInit(): void {}
}
