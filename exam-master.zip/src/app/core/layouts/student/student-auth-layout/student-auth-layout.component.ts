import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'student-auth-layout',
	templateUrl: './student-auth-layout.component.html',
	styleUrls: ['./student-auth-layout.component.css']
})
export class StudentAuthLayoutComponent implements OnInit {
	constructor() {}

	ngOnInit(): void {}
}
