import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'student-master-layout',
	templateUrl: './student-master-layout.component.html',
	styleUrls: ['./student-master-layout.component.css']
})
export class StudentMasterLayoutComponent implements OnInit {
	constructor() {}

	ngOnInit(): void {}
}
