import { Subscription } from 'rxjs';
import { Component, OnDestroy } from '@angular/core';
import { AuthenticationService } from '@core/authentication';
import { Event, NavigationEnd, Router } from '@angular/router';

@Component({
	selector: 'student-master-header',
	templateUrl: './student-master-header.component.html',
	styleUrls: ['./student-master-header.component.css']
})
export class StudentMasterHeaderComponent implements OnDestroy {
	constructor(
		private _router: Router,
		private _authService: AuthenticationService
	) {
		this.routeHandler();
	}

	public isStudentAuthenticated!: boolean;
	private subscriptions: Subscription[] = [];

	public onLogoutStudent(event: MouseEvent): void {
		event.preventDefault();
		this._authService.clearStudentAccessToken();
		this._router.navigate(['/home']);
	}

	private routeHandler() {
		this.subscriptions.push(
			this._router.events.subscribe({
				next: (event: Event) => {
					if (event instanceof NavigationEnd) {
						this.isStudentAuthenticated =
							this._authService.isStudentAuthenticated();
					}
				}
			})
		);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) =>
			subscription.unsubscribe()
		);
	}
}
