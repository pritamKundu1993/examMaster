import { Injectable } from '@angular/core';
import { AuthenticationService } from '../authentication';
import {
	Router,
	CanActivate,
	RouterStateSnapshot,
	ActivatedRouteSnapshot
} from '@angular/router';

@Injectable()
export class StudentAuthGuard implements CanActivate {
	constructor(
		private _router: Router,
		private _authService: AuthenticationService
	) {}

	canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	): boolean {
		const isLoggedIn = this._authService.isStudentAuthenticated();

		if (isLoggedIn) {
			// authorised so return true
			return true;
		}

		// not logged in so redirect to login page
		console.error('Not authenticated, redirecting...');
		this._router.navigate(['/auth/student-login']);
		return false;
	}
}
