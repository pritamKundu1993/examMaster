import { Injectable } from '@angular/core';
import { AuthenticationService } from '../authentication';
import {
	Router,
	CanActivate,
	ActivatedRouteSnapshot,
	RouterStateSnapshot
} from '@angular/router';

@Injectable()
export class AdminAuthGuard implements CanActivate {
	constructor(
		private _router: Router,
		private _authService: AuthenticationService
	) {}

	canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	): boolean {
		const isLoggedIn = this._authService.isAdminAuthenticated();

		if (isLoggedIn) {
			// authorised so return true
			return true;
		}

		// not logged in so redirect to login page
		console.error('Not authenticated, redirecting...');
		this._router.navigate(['/auth/admin-login']);
		return false;
	}
}
