import { Injectable } from '@angular/core';
import { AuthenticationService } from '../authentication';
import {
	Router,
	CanActivate,
	RouterStateSnapshot,
	ActivatedRouteSnapshot
} from '@angular/router';

@Injectable()
export class SecureOuterPagesGuard implements CanActivate {
	constructor(
		private _router: Router,
		private _authService: AuthenticationService
	) {}

	canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	): boolean {
		const isLoggedIn = this._authService.isStudentAuthenticated();

		if (isLoggedIn) {
			const url = route.url[0].toString();
			switch (url) {
				case 'student-login':
					this._router.navigate(['/student-profile']);
					return false;
				case 'student-registration':
					this._router.navigate(['/student-profile']);
					return false;
				default:
					return false;
			}
		}

		// not logged in so redirect to login page with the return url
		return true;
	}
}
