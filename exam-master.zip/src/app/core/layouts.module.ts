import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

//Student layout components import
import {
	StudentAuthLayoutComponent,
	StudentMasterLayoutComponent,
	StudentMasterHeaderComponent
} from './layouts/student';

//Admin layout components import
import {
	AdminAuthLayoutComponent,
	AdminMasterLayoutComponent,
	AdminMasterHeaderComponent
} from './layouts/admin';

const COMPONENTS = [
	AdminAuthLayoutComponent,
	StudentAuthLayoutComponent,
	AdminMasterLayoutComponent,
	AdminMasterHeaderComponent,
	StudentMasterLayoutComponent,
	StudentMasterHeaderComponent
];

@NgModule({
	exports: [...COMPONENTS],
	declarations: [...COMPONENTS],
	imports: [CommonModule, RouterModule]
})
export class LayoutsModule {}
