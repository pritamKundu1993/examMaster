import { Observable, map } from 'rxjs';
import { IStudent } from '@shared/models';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class StudentsService {
	constructor(private _http: HttpClient) {}

	private requestEndpoint: string = environment.host;

	public fetchStudents(): Observable<IStudent[]> {
		return this._http.get<IStudent[]>(this.requestEndpoint + `/students`);
	}

	public fetchStudent(studentId: string): Observable<IStudent | null> {
		return this._http
			.get<IStudent[]>(this.requestEndpoint + '/students', {
				params: { studentId }
			})
			.pipe(
				map((students) => {
					return students?.shift() ?? null;
				})
			);
	}

	public addStudent(payload: IStudent): Observable<IStudent> {
		return this._http.post<IStudent>(
			this.requestEndpoint + `/students`,
			payload
		);
	}

	public updateStudent(payload: Partial<IStudent>): Observable<IStudent> {
		return this._http.patch<IStudent>(
			this.requestEndpoint + `/students/${payload.id}`,
			payload
		);
	}

	public deleteStudent(id: number): Observable<void> {
		return this._http.delete<void>(
			this.requestEndpoint + `/students/${id}`
		);
	}
}
