import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { IAdmin } from '@shared/models';
import { environment } from '@env/environment';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AdminService {
	constructor(private _http: HttpClient) {}
	private requestEndpoint: string = environment.host;

	public fetchAdmins(): Observable<IAdmin[]> {
		return this._http.get<IAdmin[]>(this.requestEndpoint + '/admins');
	}

	public fetchAdmin(
		email: string,
		password?: string
	): Observable<IAdmin | null> {
		return this._http
			.get<IAdmin[]>(this.requestEndpoint + '/admins', {
				params: { email, ...(!!password && { password }) }
			})
			.pipe(
				map((admins) => {
					return admins?.shift() ?? null;
				})
			);
	}

	public addAdmin(payload: IAdmin): Observable<IAdmin> {
		return this._http.post<IAdmin>(
			this.requestEndpoint + `/admins`,
			payload
		);
	}
}
