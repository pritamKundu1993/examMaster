export const environment = {
	production: true,
	host: 'http://localhost:3000'
};
